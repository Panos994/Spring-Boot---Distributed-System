#sqlite db #tested with Postman and Swagger #after you sign up, login you can test all the methods from our restCOntrollers using Postman or Swagger! #in our pdf we have screenshots and the link from swagger

#application server on localhost:9090
