package gr.hua.agricoop.entity;

public enum Status {
    APPROVED, REJECTED, PROCESSING
}
