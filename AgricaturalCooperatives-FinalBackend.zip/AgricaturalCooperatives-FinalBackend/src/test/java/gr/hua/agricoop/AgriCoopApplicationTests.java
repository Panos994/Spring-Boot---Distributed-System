package gr.hua.agricoop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriCoopApplicationTests {

	@Test
	void contextLoads() {
	}

}
