# myfrontend

## Files needed 
## 1. include package.json and package-lock.json files 
## for installing the project's dependencies
## 2. files of src directory 


##Run the application server from your IDE (port: 9090)

## Project setup frontend (port: 8080): open Intellij terminal or your OS terminal 
# -->cd AgriculturalCooperatives --> cd frontend
```
npm install
```

### Compiles and hot-reloads for development
## you are running the frontend project
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
